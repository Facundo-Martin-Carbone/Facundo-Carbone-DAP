class Post {
  String title;
  String description;
  String imagesrc;
  String text;

  Post({required this.title, required this.description, required this.imagesrc, required this.text});
}