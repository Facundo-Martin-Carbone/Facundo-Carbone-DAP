package com.example.login_app_dyner_carbone_yedid_poretti

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
